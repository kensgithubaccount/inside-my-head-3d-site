# Inside My Head — 3D Hero (Next.js 14 + three.js)

## Run locally
```bash
npm i
npm run dev
# http://localhost:3000
```

## Deploy (Vercel)
Import this repo on Vercel (Next.js auto-detected). No env vars required.

The brain is generated procedurally (two hemispheres) — no GLB files needed.
